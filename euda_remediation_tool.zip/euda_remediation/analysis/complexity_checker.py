import os

def calculate_complexity(file_path, parsed_data):
    score = 0
    total_links = 0
    for sheet, data in parsed_data.items():
        score += len(data['formulas']) + len(data['external_links'])
        total_links += len(data['external_links'])

    macro_present = file_path.endswith('.xlsm')
    sensitivity = 'HIGH' if total_links > 5 else 'LOW'

    return {
        "complexity_score": score,
        "macro_detected": macro_present,
        "external_links": total_links,
        "data_sensitivity": sensitivity
    }
