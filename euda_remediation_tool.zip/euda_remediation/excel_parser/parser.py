import openpyxl
import os

def parse_excel(file_path):
    workbook = openpyxl.load_workbook(file_path, data_only=False, keep_vba=True)
    report = {}

    for sheet in workbook.sheetnames:
        ws = workbook[sheet]
        sheet_info = {
            'formulas': [],
            'values': [],
            'external_links': [],
        }

        for row in ws.iter_rows():
            for cell in row:
                if cell.data_type == 'f':
                    sheet_info['formulas'].append(cell.coordinate + ": " + str(cell.value))
                elif isinstance(cell.value, str) and 'http' in cell.value:
                    sheet_info['external_links'].append(cell.coordinate + ": " + str(cell.value))
                else:
                    sheet_info['values'].append(cell.coordinate + ": " + str(cell.value))

        report[sheet] = sheet_info
    return report
