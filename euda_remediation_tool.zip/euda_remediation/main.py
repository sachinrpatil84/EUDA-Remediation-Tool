from excel_parser.parser import parse_excel
from analysis.complexity_checker import calculate_complexity
from embedding.vector_store import embed_text, store_embedding_in_pg
from reporting.report_generator import generate_report
import psycopg2

def main():
    file_path = "samples/sample_euda.xlsx"
    parsed = parse_excel(file_path)
    analysis = calculate_complexity(file_path, parsed)

    text_summary = str(parsed) + str(analysis)
    embedding = embed_text(text_summary)

    conn = psycopg2.connect(
        host="localhost", database="euda_db", user="user", password="password"
    )

    store_embedding_in_pg(embedding, {"file": file_path, "analysis": analysis}, conn)
    generate_report(parsed, analysis)

if __name__ == "__main__":
    main()
