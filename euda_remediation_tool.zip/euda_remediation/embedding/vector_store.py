def embed_text(text):
    return [0.123] * 1536  # Dummy 1536-dim vector

def store_embedding_in_pg(vector, metadata, conn):
    with conn.cursor() as cur:
        cur.execute("""
            INSERT INTO euda_vectors (embedding, metadata)
            VALUES (%s, %s)
        """, (vector, metadata))
        conn.commit()
