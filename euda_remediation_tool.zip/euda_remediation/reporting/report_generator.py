def generate_report(parsed, analysis):
    for sheet, data in parsed.items():
        print(f"\nSheet: {sheet}")
        print("Formulas:")
        for f in data['formulas'][:3]:
            print(f)
    print("\n--- Analysis Summary ---")
    print(f"Complexity Score: {analysis['complexity_score']}")
    print(f"Macros Detected: {analysis['macro_detected']}")
    print(f"External Links Found: {analysis['external_links']}")
    print(f"Data Sensitivity: {analysis['data_sensitivity']}")
