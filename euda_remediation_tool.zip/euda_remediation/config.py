# config.py
# Placeholder for storing credentials, constants etc.
DB_CONFIG = {
    'host': 'localhost',
    'database': 'euda_db',
    'user': 'user',
    'password': 'password'
}
